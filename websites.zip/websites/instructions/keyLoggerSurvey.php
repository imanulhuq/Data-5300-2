<?php
//Test URL: http://www.surveystudy.com/keyLoggerSurvey.php?Trust_Level=trust&Confidence_Level=vconf&ResponseTime=1450396779437&TrialNo=25&PageLoadTime=1450396775854&ParticipantNo=001

$Trust_Level=$_GET['Trust_Level'];
$Confidence_Level = $_GET['Confidence_Level'];
$responseTime=$_GET['ResponseTime'];
$pageLoadTime=$_GET['PageLoadTime'];
$trialNo=$_GET['TrialNo'];
$participantNo=$_GET['ParticipantNo'];

$myFileDir = '../Survey_Logs/'.$participantNo;

if (!file_exists($myFileDir)) {
    mkdir($myFileDir);
} 

$fileName = $myFileDir.'/SurveyResponseLog.txt';
//Now write in the file
$Handle = fopen($fileName, 'a');
$trialName = "Trial:".$trialNo."\r\n";
fwrite($Handle, $trialName); 
$Page_Load_Time = "ResponsePage_Onset_time:".$pageLoadTime."\t\r\n";
fwrite($Handle, $Page_Load_Time); 
$response ="Know_Website:".$Trust_Level."\t\r\n";
fwrite($Handle, $response); 
$response ="Have_Account:".$Confidence_Level."\t\r\n";
fwrite($Handle, $response); 
$response_time="Response_Time:".$responseTime."\t\r\n\n";
fwrite($Handle,$response_time);
//fwrite($Handle,"\n\t")
fclose($Handle); 
?>